import { Routes, Route, Navigate } from "react-router-dom";

import MhsaHome from "./mhsa_home";
import TuggerMap from "./TuggerMap";
import RelationshipsERD from "./RelationshipsERD";
import Search from "./Search";
import Maintenance from "./Maintenance";
import CartMoveMenu from "./CartMoveMenu";
import Carts from "./Carts";
import MhsaWorkflowMenu from "./MhsaWorkflowMenu";
import Scoreboard from "./Scoreboard";
import ScanEvents from "./ScanEvents"; // adjust path if needed
import SignalsDashboard from "./SignalsDashboard";
import CockpitPage from "./Cockpit";
import MaterialHandlingCostTable from "./MaterialHandlingCostTable";
import QueueManager from "./QueueManager";
import FlightManifestPreview from "./Flight_Manifest_preview";
import AnticipationPage from "./Anticipation";

//import RequireSession from "../../components/RequireSession"; //  this queries the backend for session status
import ProtectedMhsaPage from "../../components/ProtectedMhsaPage";

//import "./mhsa.theme.clubcar.css";
import "../../components/mhsa.theme.clubcar.css";
import "./mhsa_home.css"; // or mhsa.base.css when you rename it

// future placeholders
// import PartSearch from "./PartSearch";
// import RelationshipsERD from "./RelationshipsERD";

export default function ClubcarRouter() {
  console.log("[ClubCarRouter] production guard build active");
  return (
    <div className="mhsa-home mhsa-dark">
      <div style={{ padding: 30, color: "red", fontSize: 28 }}>
        ROUTER TEST — NEW BUILD IS ACTIVE
      </div>

      <Routes>
        {/* default /clubcar */}
        <Route index element={<MhsaHome />} />
        {/* key demo pages */}
        <Route
          path="mhsa"
          element={
            <ProtectedMhsaPage>
              <MhsaHome />
            </ProtectedMhsaPage>
          }
        />
        <Route path="scoreboard" element={<Scoreboard />} />
        <Route path="tugger-map" element={<TuggerMap />} />
        <Route path="cockpit" element={<CockpitPage />} />
        <Route path="relationships" element={<RelationshipsERD />} />
        {/* NEW: Search */}
        <Route path="search" element={<Search />} />
        <Route path="search/:mode" element={<Search />} />
        {/* NEW: Scan Events (live feed) */}
        <Route path="scan-events" element={<ScanEvents />} />

        <Route path="maintenance" element={<Maintenance />} />
        <Route path="CostTable" element={<MaterialHandlingCostTable />} />
        <Route path="maintenance/:tool" element={<Maintenance />} />
        <Route path="cart-move" element={<CartMoveMenu />} />
        <Route path="carts" element={<Carts />} />
        <Route path="workflows" element={<MhsaWorkflowMenu />} />
        <Route path="signals" element={<SignalsDashboard />} />
        <Route path="queue-manager" element={<QueueManager />} />
        <Route path="anticipation" element={<AnticipationPage />} />
        <Route
          path="flight-manifest-preview"
          element={<FlightManifestPreview />}
        />

        {/* <Route path="/mhsa/maintenance" element={<Maintenance />} /> */}
        {/* fallback */}
        <Route path="*" element={<Navigate to="/clubcar" replace />} />
      </Routes>
    </div>
  );
}
