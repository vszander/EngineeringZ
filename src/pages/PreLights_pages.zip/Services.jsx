function OurServices() {
    return (
      <div className="container">
        <h1>Service Offerings</h1>
        <p>This page contains information about Services.</p>
      </div>
    );
  }
  
  export default OurServices;