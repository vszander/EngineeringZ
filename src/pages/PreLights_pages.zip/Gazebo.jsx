function Gazebo() {
  return (
    <div className="container">
      <h1>Gazebo  Page</h1>
      <p>This page contains information about Gazebo.</p>
    </div>
  );
}

export default Gazebo;
