
function ThreeD() {
  return (
    <div className="container">
      <h1>3-D Page</h1>
      <p>This page contains information about 3-D prints.</p>
      https://9dcef3a3-0c97-49d1-8ad0-6d151fe29635.paylinks.godaddy.com/IC7300_rails

      <img src="https://images.unsplash.com/photo-1578271887552-5ac3a72752bc?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1950&q=80" class="img-fluid border-radius-lg" alt="Responsive image"/>


    </div>
  );
}

export default ThreeD;